DELETE FROM harProgram;
DELETE FROM Butik;

INSERT INTO public.coordinator(ID, name, password) VALUES (6000, 'Anna', '$2b$12$KFkp1IEMGT4QrWwjPGhE3ejOv6Z3pYhx/S4qOoFbanR2sMiZqgeJO');
